create trigger remove_question
  after DELETE
  on questions
  for each row
  update tests set totalQuestions = totalQuestions - 1 where tests.id = OLD.testId;

