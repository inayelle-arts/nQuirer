create trigger add_question
  after INSERT
  on questions
  for each row
  update tests set totalQuestions = totalQuestions + 1 where tests.id = NEW.testId;

